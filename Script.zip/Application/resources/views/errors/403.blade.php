@extends('errors.layout')
@section('title', lang('Forbidden', 'error pages'))
@section('code', '403')
@section('message', lang('Forbidden', 'error pages'))
