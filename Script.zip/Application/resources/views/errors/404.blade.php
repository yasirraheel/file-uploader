@extends('errors.layout')
@section('title', lang('Page Not Found', 'error pages'))
@section('code', '404')
@section('message', lang('Page Not Found', 'error pages'))
