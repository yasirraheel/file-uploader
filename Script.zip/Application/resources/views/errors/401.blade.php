@extends('errors.layout')
@section('title', lang('Unauthorized', 'error pages'))
@section('code', '401')
@section('message', lang('Unauthorized', 'error pages'))
