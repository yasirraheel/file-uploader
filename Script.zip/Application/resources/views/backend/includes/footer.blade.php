<footer>
    <p class="mb-0"> &copy; <span data-year></span> {{ $settings['website_name'] }} -
        {{ __('All rights reserved.') }}</p>
    <p class="mb-0 ms-auto">{{ __('Powered by Vironeer') }}</p>
</footer>
